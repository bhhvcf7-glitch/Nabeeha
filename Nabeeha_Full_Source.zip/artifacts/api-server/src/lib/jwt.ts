import jwt from "jsonwebtoken";

const SECRET = process.env.SESSION_SECRET ?? "nabeeh-bank-secret-2026";

export interface JwtPayload {
  userId: string;
  email: string;
}

export function signToken(payload: JwtPayload): string {
  return jwt.sign(payload, SECRET, { expiresIn: "30d" });
}

export function verifyToken(token: string): JwtPayload {
  return jwt.verify(token, SECRET) as JwtPayload;
}
