"""Create the six-page Nabeeha project research report (requires pymupdf)."""
from pathlib import Path
import fitz

ROOT = Path(__file__).resolve().parents[1]
PAGES = [
('NABEEHA / 01', 'نبيهه | NABEEHA', 'Intelligent financial experience', [
 'A cross-platform banking-interface prototype with a bilingual research security laboratory.',
 'تجربة مالية حديثة تجمع لوحة حسابات وبطاقات ومؤشرات مالية، مع شاشة حماية ذكية جديدة بالعربي والإنجليزي.',
 'Research prototype · Mobile experience · Guardian PRISM V16']),
('VISION / 02', 'المشكلة والفرصة', 'Problem & opportunity', [
 'Modern financial applications need transparent security decisions, not unexplained red flags.',
 'يحاول نبيهه شرح قرار السماح أو التحقق أو المنع وفق تكلفة متوقعة وافتراضات معروفة.',
 'The attached original codebase includes mobile screens and a typed API. The security lab was integrated as a separate module.']),
('SYSTEM / 03', 'المنظومة والبنية', 'Architecture & components', [
 'Client: Expo Router, React Native, TypeScript, reusable UI components and account views.',
 'Service: Express API, typed contracts, shared clients and database layer in a pnpm workspace.',
 'Guardian module: isolated JavaScript decision engine and native bilingual mobile simulator.',
 'Entry point: Profile → Guardian PRISM, with EN / عربي language switch.']),
('DECISION / 04', 'منطق القرار', 'Explainable risk mathematics', [
 'Assumptions: fraud loss = SAR 9,000; verification inconvenience = SAR 40; false block cost = SAR 600.',
 'Allow = 9000p; Verify = 9000rp + 40(1-p); Block = 600(1-p).',
 'Mixed residual success: 0.5×2% + 0.3×3% + 0.2×40% = 9.9%.',
 'Under these assumptions, allow/verify threshold is about 0.49%; verify/block threshold about 38.59%.',
 'Hold is recommended only if its modelled value is positive and evidence level is eligible.']),
('VERIFICATION / 05', 'الاختبارات والنتائج', 'Validation & claims', [
 'Fourteen Node.js unit tests passed for the added Guardian PRISM risk-engine module.',
 'Test cases cover mixed attacker weights, invalid inputs, action selection, thresholds, hold and audit mechanics.',
 'These tests do NOT validate real fraud detection, cryptographic consent, banking authorization or the entire app.',
 'The uploaded source was based on an existing application; its original screens require independent integration testing.']),
('NEXT / 06', 'خارطة الطريق', 'Responsible development roadmap', [
 'R1 — finish application-wide Arabic/English localization, RTL quality and accessibility testing.',
 'R2 — replace demonstration credentials and implement secure identities with WebAuthn/Passkeys.',
 'R3 — enforce transaction authorization server-side with replay-proof storage and audit trails.',
 'R4 — GuardianBench: compare against baselines, quantify cost and uncertainty on consented synthetic data.',
 'R5 — only after independent security review, consider an authorized pilot.']),
]
CSS='''body{font-family:"Noto Sans Arabic",Arial,sans-serif;direction:rtl;color:#193a49;line-height:1.9}h1{font-size:36px;color:#0c4b60;margin:25px 0 10px}h2{font-size:17px;color:#0b9388}.tag{font-size:12px;letter-spacing:2px;color:#13b4a5;font-weight:bold}.item{background:#eff7f7;border-right:4px solid #1eb8a8;border-radius:7px;margin:14px 0;padding:16px;font-size:14px;color:#315969}.cover-title{font-size:55px;color:#fff;margin-top:105px}.cover-sub{font-size:23px;color:#a3ebdf}.cover-text{font-size:17px;color:#ebfafa}'''
doc=fitz.open()
for i,(tag,title,subtitle,lines) in enumerate(PAGES):
    page=doc.new_page(width=595,height=842)
    if i==0:page.draw_rect(page.rect,color=None,fill=(.035,.14,.21))
    blocks=''.join('<div class="item">'+line+'</div>' for line in lines)
    if i==0:
        body=f'<div class="tag">{tag}</div><div class="cover-title">{title}</div><div class="cover-sub">{subtitle}</div><div class="cover-text">{lines[0]}<p>{lines[1]}</p>{lines[2]}</div>'
    else:
        body=f'<div class="tag">{tag}</div><h1>{title}</h1><h2>{subtitle}</h2>{blocks}'
    remainder,scale=page.insert_htmlbox(fitz.Rect(55,65,538,772),f'<html><body>{body}</body></html>',css=CSS,scale_low=.7)
    if remainder<0:raise RuntimeError(f'Could not fit report page {i+1}')
    if i:
        page.draw_line((55,789),(537,789),color=(.74,.85,.86))
        page.insert_text((55,807),'NABEEHA / RESEARCH PROTOTYPE',fontsize=8,color=(.4,.6,.64))
        page.insert_text((523,807),str(i+1).zfill(2),fontsize=8,color=(.4,.6,.64))
output=ROOT/'PROJECT_REPORT.pdf'
doc.save(output,garbage=4,deflate=True)
print('Created',output,'pages',len(doc))
